# Password Strength Analyzer

A small Python desktop app that checks a password and gives clear suggestions for making it stronger.

## Features
- Checks password length, uppercase/lowercase letters, numbers and special characters.
- Shows a simple strength rating: Weak, Fair or Strong.
- Gives suggestions while you type.
- Includes a checklist and a show/hide password option.
- Flags a few very common passwords and obvious sequences.

## Requirements
- Python 3.10 or newer
- Tkinter (included with most standard Windows Python installations)

No extra packages or internet connection are required.

## Run it
1. Download and extract this folder.
2. Open Command Prompt in the project folder.
3. Run:

   ```bash
   python password_analyzer.py
   ```

   On some Windows installations, use `py password_analyzer.py`.

## How it works
The program uses regular expressions to check for character types and counts how many checks pass. It then assigns a basic rating and displays tips for missing requirements.

## Important note
This is a learning project, not a professional password-auditing tool. The score is a simple checklist, not a guarantee of how long a password would resist guessing. The app analyses the password locally and does not save or send it anywhere. For real accounts, use a password manager and enable multi-factor authentication when possible.
