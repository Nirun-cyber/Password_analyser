import re
import tkinter as tk
from tkinter import messagebox


COMMON_PASSWORDS = {
    "password", "password123", "123456", "123456789", "qwerty",
    "admin", "letmein", "welcome", "iloveyou", "abc123"
}


def analyze_password(password):
    """Check a password's strength and return practical feedback."""
    checks = {
        "At least 8 characters": len(password) >= 8,
        "At least 12 characters (recommended)": len(password) >= 12,
        "Contains lowercase letters": bool(re.search(r"[a-z]", password)),
        "Contains uppercase letters": bool(re.search(r"[A-Z]", password)),
        "Contains a number": bool(re.search(r"\d", password)),
        "Contains a special character": bool(re.search(r"[^A-Za-z0-9]", password)),
    }

    score = sum([
        len(password) >= 8,
        len(password) >= 12,
        bool(re.search(r"[a-z]", password)),
        bool(re.search(r"[A-Z]", password)),
        bool(re.search(r"\d", password)),
        bool(re.search(r"[^A-Za-z0-9]", password)),
    ])

    issues = []
    if len(password) < 8:
        issues.append("Use at least 8 characters. A longer password is better.")
    if len(password) < 12:
        issues.append("Aim for 12 or more characters.")
    if not re.search(r"[a-z]", password):
        issues.append("Add a lowercase letter.")
    if not re.search(r"[A-Z]", password):
        issues.append("Add an uppercase letter.")
    if not re.search(r"\d", password):
        issues.append("Add a number.")
    if not re.search(r"[^A-Za-z0-9]", password):
        issues.append("Add a special character, such as !, @, or #.")
    if password.lower() in COMMON_PASSWORDS:
        issues.append("This is a commonly used password. Choose something less predictable.")
        score = 0

    if not password:
        strength = "Enter a password"
    elif password.lower() in COMMON_PASSWORDS or score <= 2:
        strength = "Weak"
    elif score <= 4:
        strength = "Fair"
    else:
        strength = "Strong"

    # Repeated characters and simple sequences can make passwords easier to guess.
    if len(password) >= 4 and len(set(password)) == 1:
        issues.append("Avoid using the same character repeatedly.")
    if password and re.search(r"(1234|abcd|qwerty)", password.lower()):
        issues.append("Avoid obvious keyboard or number sequences.")

    if not issues and password:
        issues.append("Nice work. Keep this password unique to one account.")

    return strength, checks, issues


class PasswordAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Password Strength Analyzer")
        self.root.geometry("520x600")
        self.root.minsize(460, 540)
        self.root.configure(bg="#f5f7fb")

        self.password_visible = tk.BooleanVar(value=False)

        tk.Label(
            root, text="Password Strength Analyzer",
            font=("Segoe UI", 20, "bold"), bg="#f5f7fb", fg="#18233a"
        ).pack(pady=(24, 6))

        tk.Label(
            root,
            text="Check a password and get simple ways to improve it.",
            font=("Segoe UI", 10), bg="#f5f7fb", fg="#596579"
        ).pack(pady=(0, 18))

        input_frame = tk.Frame(root, bg="#ffffff", padx=16, pady=16,
                               highlightbackground="#dfe5ef", highlightthickness=1)
        input_frame.pack(fill="x", padx=24)

        tk.Label(input_frame, text="Enter password", font=("Segoe UI", 10, "bold"),
                 bg="#ffffff", fg="#26334b").pack(anchor="w")

        self.password_entry = tk.Entry(
            input_frame, font=("Segoe UI", 13), show="•", relief="solid",
            bd=1, highlightthickness=0
        )
        self.password_entry.pack(fill="x", pady=(8, 10), ipady=7)
        self.password_entry.bind("<KeyRelease>", lambda event: self.analyze())

        tk.Checkbutton(
            input_frame, text="Show password", variable=self.password_visible,
            command=self.toggle_password, bg="#ffffff", activebackground="#ffffff",
            font=("Segoe UI", 9), fg="#596579"
        ).pack(anchor="w")

        self.strength_label = tk.Label(
            root, text="Strength: —", font=("Segoe UI", 14, "bold"),
            bg="#f5f7fb", fg="#596579"
        )
        self.strength_label.pack(pady=(20, 6))

        self.progress_canvas = tk.Canvas(root, height=10, bg="#e2e8f0",
                                         highlightthickness=0)
        self.progress_canvas.pack(fill="x", padx=28)
        self.progress_bar = self.progress_canvas.create_rectangle(
            0, 0, 0, 10, fill="#64748b", width=0
        )

        tk.Label(root, text="Security checklist", font=("Segoe UI", 11, "bold"),
                 bg="#f5f7fb", fg="#26334b").pack(anchor="w", padx=28, pady=(20, 6))

        self.checklist = tk.Frame(root, bg="#f5f7fb")
        self.checklist.pack(fill="x", padx=30)
        self.check_labels = []
        for _ in range(6):
            label = tk.Label(self.checklist, text="", font=("Segoe UI", 9),
                             bg="#f5f7fb", fg="#596579", anchor="w")
            label.pack(fill="x", pady=1)
            self.check_labels.append(label)

        tk.Label(root, text="Suggestions", font=("Segoe UI", 11, "bold"),
                 bg="#f5f7fb", fg="#26334b").pack(anchor="w", padx=28, pady=(18, 5))

        self.suggestions = tk.Label(
            root, text="Start typing to see suggestions.", justify="left",
            anchor="nw", wraplength=450, font=("Segoe UI", 9),
            bg="#f5f7fb", fg="#596579"
        )
        self.suggestions.pack(fill="x", padx=30)

        tk.Label(
            root, text="Tip: never reuse a password across important accounts.",
            font=("Segoe UI", 8), bg="#f5f7fb", fg="#7a8597"
        ).pack(side="bottom", pady=14)

    def toggle_password(self):
        self.password_entry.configure(show="" if self.password_visible.get() else "•")

    def analyze(self):
        password = self.password_entry.get()
        strength, checks, issues = analyze_password(password)

        colors = {
            "Enter a password": "#596579",
            "Weak": "#dc2626",
            "Fair": "#d97706",
            "Strong": "#059669",
        }
        self.strength_label.configure(
            text=f"Strength: {strength}", fg=colors.get(strength, "#596579")
        )

        score = sum([
            len(password) >= 8,
            len(password) >= 12,
            bool(re.search(r"[a-z]", password)),
            bool(re.search(r"[A-Z]", password)),
            bool(re.search(r"\d", password)),
            bool(re.search(r"[^A-Za-z0-9]", password)),
        ])
        if password.lower() in COMMON_PASSWORDS:
            score = 0
        width = self.progress_canvas.winfo_width()
        self.progress_canvas.coords(self.progress_bar, 0, 0, width * score / 6, 10)
        self.progress_canvas.itemconfigure(self.progress_bar, fill=colors.get(strength, "#64748b"))

        for label, (name, passed) in zip(self.check_labels, checks.items()):
            symbol = "✓" if passed else "○"
            color = "#059669" if passed else "#7a8597"
            label.configure(text=f"{symbol}  {name}", fg=color)

        if password and issues:
            self.suggestions.configure(text="\n".join(f"• {issue}" for issue in issues))
        else:
            self.suggestions.configure(text="Start typing to see suggestions.")


if __name__ == "__main__":
    window = tk.Tk()
    app = PasswordAnalyzerApp(window)
    window.mainloop()
